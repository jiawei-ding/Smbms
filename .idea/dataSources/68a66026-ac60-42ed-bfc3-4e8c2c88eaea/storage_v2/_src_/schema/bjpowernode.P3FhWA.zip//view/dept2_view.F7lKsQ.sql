create view dept2_view as
select `bjpowernode`.`dept2`.`DEPTNO` AS `DEPTNO`,
       `bjpowernode`.`dept2`.`DNAME`  AS `DNAME`,
       `bjpowernode`.`dept2`.`LOC`    AS `LOC`
from `bjpowernode`.`dept2`;

